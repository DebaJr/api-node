const BCrypt = require('bcrypt');
const UserRepository = require('../repositories/userRepository');
const {v4: UUIDV4} = require('uuid');

const SECRET_KEY = 'chave_secreta'

class UserService {
    async getAll(){
        return UserRepository.findAll();
    }

    async getByUsername(username){
        return UserRepository.findByUsername(username);
    }

    async register(username, password){
        if (username === "") {
            throw new Error('Preencha o nome de usuário');
        }

        if(password === "") {
            throw new Error('Preencha a senha');
        }

        const user = await this.getByUsername(username);

        if (user) {
            throw new Error('Nome de usuário indisponível');
        }

        const hashedPassword = await BCrypt.hash(password, 10);
        const id = UUIDV4();

        return await UserRepository.createUser({id,username,password:hashedPassword})
    }
}

module.exports = new UserService();