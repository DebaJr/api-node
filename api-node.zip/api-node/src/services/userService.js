const BCrypt = require('bcrypt');
const UserRepository = require('../repositories/userRepository');
const {v4: UUIDV4} = require('uuid');
const jwt = require('jsonwebtoken');

const SECRET_KEY = 'chave_secreta'

class UserService {
    async getAll(){
        return UserRepository.findAll();
    }

    async getByUsername(username){
        return UserRepository.findByUsername(username);
    }

    async register(username, password){
        if (username === "") {
            throw new Error('Preencha o nome de usuário');
        }

        if(password === "") {
            throw new Error('Preencha a senha');
        }

        const user = await this.getByUsername(username);

        if (user) {
            throw new Error('Nome de usuário indisponível');
        }

        const hashedPassword = await BCrypt.hash(password, 10);
        const id = UUIDV4();

        return await UserRepository.createUser({id,username,password:hashedPassword})
    }

    async login(username, password){
        const user = await this.getByUsername(username);
        if (!user) {
            throw new Error('Usuário e/ou Senha inválido(os)');
        }

        const isValidPassword = await BCrypt.compare(password, user.password);

        if (!isValidPassword) {
            throw new Error('Usuário e/ou Senha inválido(os)');
        }

        const token = jwt.sign({id:user.id},SECRET_KEY,{expiresIn:'1h'})
        return token;
    }

    async delete(username){
        const user = await this.getByUsername(username);
        if(!user){
            throw new Error('Usuário inválido');
        }

        UserRepository.delete(user.id);
    }
}

module.exports = new UserService();