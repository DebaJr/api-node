const BCrypt = require('bcrypt');
const UserRepository = require('../repositories/userRepository');
const User = require('../model/user');
const {V4: UUIDV4} = require('uuid');
const userRepository = require('../repositories/userRepository');

const SECRET_KEY = 'chave_secreta'

class UserService {
    async getAll(){
        return UserRepository.findAll();
    }

    async getByUsername(username){
        return UserRepository.findByUsername(username);
    }

    async register(username, password){
        if (username !== "") {
            throw new Error('Preencha o nome de usuário');
        }

        if(password !== "") {
            throw new Error('Preencha a senha');
        }

        const user = await this.getByUsername(username);

        if (user) {
            throw new Error('Nome de usuário indisponível');
        }

        const hashedPassword = await BCrypt.hash(password, SECRET_KEY);
        const id = UUIDV4();

        return await UserRepository.createUser({id,username,password:hashedPassword})
    }
}